
const { roles } = require('xmtoolbox');
const { prod, xm } = require('./config');
const userPath = './input/users.csv';
const env = prod;


const updateUsers = async () => {

    let users = await xm.util.CsvToJsonFromFile(userPath);

    users = users.map(user => {

    if(user.UUID) user.id = user.UUID;
    if(user.newUserId) user.targetName = user.newUserId;
    //if(user['Web Login']) user.webLogin = user['Web Login'];
    if(user.newWebLogin) user.webLogin = user.newWebLogin;
    // if(user.roles) roles = [];
    // roles.push(user.roles);
    delete user.firstName;
    delete user.lastName;
    delete user.roles;
    delete user.newWebLogin;
    delete user.newUserId;
    delete user.UUID;
    delete user.Status;
    delete user['Web Login'];
    delete user.currentUserId;
    // user.targetName = user.newUserId;
    // if (site.latitude) site.latitude = Number(site.latitude);
    // if (site.longitude) site.longitude = Number(site.longitude);
  ///console.log(JSON.stringify(users));
    return user;

});



for (var x in users){
  if(users[x].id !== undefined && users[x].id !== "" && users[x].id !== null){
console.log(JSON.stringify(users[x]));
const update = await xm.people.update(prod, users[x], users[x].id);

//}
//    const results = await xm.sync.DataToxMatters({ sites }, env, { sites: true });
}}};

updateUsers();

